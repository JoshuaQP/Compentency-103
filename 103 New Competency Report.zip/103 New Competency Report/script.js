 var characterPoints = 100;
 var enemyPoints = 100;
 var attackPoints = 10;
 
 
 


 function display() {

     document.getElementById("character-points").innerHTML = ` <b>Points</b> ${characterPoints}`;
     document.getElementById("enemy-points").innerHTML = ` <b>Points</b> ${enemyPoints}`;


     document.getElementById('status').innerHTML = `<h2> playing...</h2>`;
 }

 function attack(p) {

     if (p === "char") {
         characterPoints = characterPoints - attackPoints;
         enemyPoints = enemyPoints + attackPoints;

        // enemypoints + attackP

     } else if (p === "enemy") {

         enemyPoints = enemyPoints - attackPoints;
         characterPoints = characterPoints + attackPoints;
     }


     display();
     checkHealth()

 }

  function checkHealth() {
    if (characterPoints == 0 || enemyPoints==0){
        gameOver()
        console.log(characterPoints)
        console.log(enemyPoints)
    }


 }

 function gameOver(){
    console.log('Game Over')
    document.getElementById('attack-btn').style.display = "none";
    document.getElementById('eattack-btn').style.display = "none";
    document.getElementById('status').innerHTML = `<h2> GAME OVER... </h2> <button onclick= "restart()"> Restart </button>  `;

    
    
 }
 
 
 display();



 function restart() {
     characterPoints = 100;
     enemyPoints = 100;

     display();
     document.getElementsById('attack-btn').style.display = "block";
     document.getElementsById('eattack-btn').style.display = "block";


 }








